from ragendja.settings_post import *

try:
    ACCOUNT_ACTIVATION_DAYS
except:
    ACCOUNT_ACTIVATION_DAYS = 30
