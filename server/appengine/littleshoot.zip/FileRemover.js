/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["littleshoot.FileRemover"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.FileRemover"] = true;
dojo.provide("littleshoot.FileRemover");

dojo.declare("littleshoot.FileRemover", null, 
    {
    constructor : function(urn, name)
        {
        this.urn = urn; 
        this.name = name;
        },
    
    removeLocal : function (keyId)
        {
        var params =
            {
            sha1 : this.urn,
            uri : this.urn,
            name : this.name,
            keyId : keyId
            };
        
        if (CommonUtils.inGroup())
            {
            params.groupName = CommonUtils.getGroupName();
            }
        var url = Constants.CLIENT_SECURE_URL + "removeFile";             
        var siteKey = dojo.cookie("siteKey");
        if (!siteKey)
            {
            User.showMessage("Error!", 
                "You don't appear to have credentials to remove files.");
            throw new Error("No site key!");
            }
        var sig = ClientApi.createSignature(url, params, siteKey);
        params.signature = sig;
        
        var removeParams =
            {
            url: url,
            timeout: 20000,
            content: params,
            handleAs: "json",
            callbackParamName: "callback",
            load: function(response, ioArgs)
                {
                //
                if (response.success)
                    {
                    var dialog = CommonUtils.createMessage("Successfully Removed", 
                        "Successfully removed the file: \""+response.fileName+"\".");
                    dojo.connect(dialog,"hide", CommonUtils.loadFiles);
                    dialog.show();
                    }
                else
                    {
                    CommonUtils.showMessage("Error Removing", 
                        response.message);
                    }
                return response;
                },
            error: function(response, ioArgs)
                {
                CommonUtils.showError(dojo.toJson(response));
                return response;
                }
            };
        
        var deferred = CommonUtils.get(removeParams);
        },
        
    removeFile : function ()
        {
        var keyId = Math.floor(Math.random() * 1000000000);
        var success = dojo.hitch(this, function (response)
            {
            
            this.removeLocal(keyId);
            });
        
        var error = dojo.hitch(this, function (response)
            {
            console.error("Got error response: "+response);
            });
        
        //
        var ok = dojo.hitch(this, function(data) 
            {
            var deferred = CommonUtils.requestKey(keyId);
            deferred.addCallback(success);
            deferred.addErrback(error);
            });
        
        CommonUtils.showConfirmDialog("Remove File?", 
            "Are you sure you want to remove \""+this.name+"\"?", ok);
        }
    });

}
