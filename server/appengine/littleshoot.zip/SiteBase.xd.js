/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.SiteBase"],
["require", "littleshoot.CommonUtils"]],
defineResource: function(dojo, dijit, dojox){if(!dojo._hasResource["littleshoot.SiteBase"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.SiteBase"] = true;
dojo.provide("littleshoot.SiteBase");
dojo.require("littleshoot.CommonUtils");

SiteBase =
    {
    onOnLoad : function()
        {
        if (!CommonUtils.isBrowserSupported())
            {
            CommonUtils.showIncompatibleBrowserDialog();
            //
            }

        littleShootConfig = 
            {
            littleShootLoading: "loading",
            
            disableAutoLoad : true,
            
            littleShootPresent : function (apiVersion) 
                {
                
                window.gotLittleShoot = true;
                //Site.appPresent();
                },
            littleShootNotPresent : function () 
                {
                
                window.gotLittleShoot = false;
                //Site.appNotPresent();
                },
            oldLittleShootVersion : function ()
                {
                
                window.gotLittleShoot = true;
                //Site.oldVersion();
                }
            };
        LittleShoot.hasLittleShoot();
        
        Button.buildButtons();
        //CommonUtils.loadUrchin();
        
        var vp = dijit.getViewport();
        if (vp.w > 1000)
            {
            
            CommonUtils.showAll(".forumsLink");
            }
        else
            {
            
            }
        
        CommonUtils.commonLoad();
        }
    };

}

}};});
