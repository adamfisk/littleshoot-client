/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.SubContentNav"],
["require", "littleshoot.CommonUtils"]],
defineResource: function(dojo, dijit, dojox){if(!dojo._hasResource["littleshoot.SubContentNav"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.SubContentNav"] = true;
dojo.provide("littleshoot.SubContentNav");
dojo.require("littleshoot.CommonUtils");

SubContentNav =
    {
    
    subContentNavNoHistory : function (contentId, subSectionId)
        {
        if (!subSectionId) 
            {
            //console.error("No subcontent ID!");
            throw new Error("Must have a subcontent ID for navigating!!");
            }
        //
        SubContentNav.subContentNavBase(contentId, subSectionId);  
        },
        
    subContentNav : function(contentId, subSectionId)
        {
        if (!contentId) 
            {
            //console.error("No content ID!");
            throw new Error("Must have a content ID for navigating!!");
            }
        var appState = new ApplicationState(contentId, subSectionId, 
            contentId+subSectionId);
        dojo.back.addToHistory(appState);
        SubContentNav.subContentNavBase(contentId, subSectionId);
        },
        
    subContentNavBase : function(contentId, subSectionId)
        {
        var subContentId = contentId + subSectionId;
        //
        var toggleableClass = contentId + "Section";
        // We first just hide everything.
        CommonUtils.hideAll("."+toggleableClass);
        
        // Then show the one we want.
        //
        var subContent = dojo.byId(subContentId);
        //
        CommonUtils.showElement(subContent);
        
        var subNavTitleText = dojo.attr(subContent, "title");//subContent.getAttribute("title");
        //
        dojo.query(".contentTitleSub", contentId).forEach(function(each)
            {
            each.innerHTML = subNavTitleText;
            });
        
        dojo.query(".subNavLinkSelected").forEach(function(toggleable) 
            {
            toggleable.className="subNavLink";
            });
            
        var subNavName = subContentId + "SubNav";
        //
        var subContentNavElement = dojo.byId(subNavName);
        
        //subContentNavElement.className="normalBoldBlack subNavLink";
        subContentNavElement.className="subNavLinkSelected";
        }
    };

}

}};});
