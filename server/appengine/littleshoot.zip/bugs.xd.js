/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {
defineResource: function(dojo, dijit, dojox){var Bugs =
    {
    reload : function()
        {
        
        var loadHandler = function(data, ioArgs)
            {
            
            };
            
        var errorHandler = function(data, ioArgs)
            {
            alert("Error: Could not contact server!");
            };
        var deferred = dojo.xhrGet(
            {
            url: "http://www.lastbamboo.org/lastbamboo-common-bug-server/topBugs", 
            handleAs: "json",
            load: loadHandler,
            error: errorHandler
            });
        }
    };

}};});
