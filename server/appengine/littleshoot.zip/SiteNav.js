/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["littleshoot.SiteNav"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.SiteNav"] = true;
dojo.provide("littleshoot.SiteNav");
dojo.require("littleshoot.CommonUtils");

/**
 * This is no longer used.
 */
SiteNav =
    {
    contentNavNoHistory : function(contentId)
        {
        if (contentId == "search") {
            SiteNav.toSearchNoHistory();
        }
        else 
            if (contentId == "publish") {
                SiteNav.toPublishNoHistory();
            }
            else {
                SiteNav.contentNavBase(contentId);
            }    
        },
        
    contentNav : function(contentId)
        {
        if (!contentId) 
            {
            //console.error("No content ID!");
            throw new Error("Must have a content ID for navigating!!");
            }
        var appState = new ApplicationState(contentId, null, contentId);
        dojo.back.addToHistory(appState);
        SiteNav.contentNavBase(contentId);
        },
        
    contentNavBase : function(contentId)
        {
        //
        
        var content = dojo.byId(contentId);
        //
        
        
        // If we've already dynamically downloaded the page we're
        // navigating to, don't do it again -- just show it.
        if (dojo.hasClass(content, "downloaded")) 
            {
            //
            SiteNav.onContent(contentId);
            }
            
        // Otherwise, we have to download it.
        else 
            {
            //
            var url = contentId + "Content.html";
            var deferredResponse = CommonUtils.getHtml(url);
            deferredResponse.addCallback(
                function(response) 
                    {
                    //
                    var contentBodyDiv = dojo.byId(contentId+"ContentBody");
                    ////
                    contentBodyDiv.innerHTML = response;
                    //
                    dojo.addClass(content, "downloaded");
                    
                    //
                    SiteNav.onContent(contentId);   
                    }
                );
            }
        },
      
    /**
     * Handles the event that content is available for a certain 
     * section.  This could mean it was downloaded, or it could mean
     * it was already present in the DOM.
     * 
     * @param {Object} contentId The DOM ID of the div containing the
     * data to change.
     */
    onContent : function (contentId)
        {
        var content = dojo.byId(contentId);
        // We first just hide everything.
        CommonUtils.hideAll(".toggleable");
        CommonUtils.hideAll(".searchToggle");
        CommonUtils.hideAll(".publishToggle");
        CommonUtils.hideAll(".resultPageDivTop");
        CommonUtils.hideAll(".resultPageDivBottom");
        CommonUtils.showAll(".siteNavToggle");
        CommonUtils.showElement(content);
        
        // Unselect them all.  We'll select one shortly.
        SiteNav.unselectNavs();
        
        // Now make the nav element for the selected page a different 
        // color.
        dojo.query("."+contentId + "Nav").forEach(function(toggleable)
            {
            dojo.removeClass(toggleable, "normalLightBold");
            dojo.addClass(toggleable, "normalBoldBlack");
            });
        
        // Activate the default sub-navigation link if there is one.
        var subSectionIdDefault = dojo.attr(content, "default");//content.getAttribute("default");
        if (subSectionIdDefault)
            {
            //
            SiteNav.subContentNavNoHistory(contentId, subSectionIdDefault);  
            }
            
        dojo.addClass(dojo.byId("leftTab"),"unselectedTab");
        dojo.removeClass(dojo.byId("leftTab"),"selectedTab");
        dojo.addClass(dojo.byId("rightTab"),"unselectedTab");
        dojo.removeClass(dojo.byId("rightTab"),"selectedTab");
        
        dijit.scrollIntoView(dojo.byId("topDiv"));
        },
            
    unselectNavs : function ()
        {
        dojo.query(".navLink").forEach(function(toggleable) 
            {
            dojo.removeClass(toggleable, "normalBoldBlack");
            dojo.addClass(toggleable, "normalLightBold");
            });    
        },
    
    toSearchNoHistory : function()
        {
        SiteNav.toSearchBase();
        },
       
    toSearch : function()
        {
        var appState = new ApplicationState("search", null, "search");
        dojo.back.addToHistory(appState);
        SiteNav.toSearchBase();
        },
        
    toSearchBase : function()
        {
        dojo.addClass(dojo.byId("leftTab"),"selectedTab");
        dojo.removeClass(dojo.byId("leftTab"),"unselectedTab");
        dojo.addClass(dojo.byId("rightTab"),"unselectedTab");
        dojo.removeClass(dojo.byId("rightTab"),"selectedTab");
        CommonUtils.hideAll(".publishToggle");
        CommonUtils.hideAll(".siteToggle");
        CommonUtils.hideAll(".siteNavToggle");
        CommonUtils.hideAll(".resultPageDivTop");
        CommonUtils.hideAll(".resultPageDivBottom");
        CommonUtils.showAll(".searchToggle");
        
        //
        SearchResultUtils.forceReload();
        },
    
    toPublishNoHistory : function()
        {
        SiteNav.toPublishBase();
        },  
                   
    toPublish : function()
        {
        var appState = new ApplicationState("publish", null, "publish");
        dojo.back.addToHistory(appState);
        SiteNav.toPublishBase();
        },  
          
    toPublishBase : function()
        {
        
        dojo.addClass(dojo.byId("leftTab"),"unselectedTab");
        dojo.removeClass(dojo.byId("leftTab"),"selectedTab");
        dojo.addClass(dojo.byId("rightTab"),"selectedTab");
        dojo.removeClass(dojo.byId("rightTab"),"unselectedTab");
        
        CommonUtils.hideAll(".searchToggle");
        CommonUtils.hideAll(".siteToggle");
        CommonUtils.hideAll(".siteNavToggle");
        CommonUtils.hideAll(".resultPageDivTop");
        CommonUtils.hideAll(".resultPageDivBottom");
        CommonUtils.showAll(".publishToggle");
        CommonUtils.showAll(".filesToggle");
        SiteNav.unselectNavs();
        
        Publisher.init();
        
        CommonUtils.loadFiles();
        if (window.searchResults)
            {
            window.searchResults.stop();
            }
        }
    };

}
