/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["littleshoot.Button"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.Button"] = true;
dojo.provide("littleshoot.Button");

Button =
    {
    changeButtonOver : function(button, bgUrl)
        {
        button.style.backgroundImage = bgUrl;
        button.style.color = "#000000";
        },
    
    changeButtonOut : function(button, bgUrl)
        {
        button.style.backgroundImage = bgUrl;
        button.style.color = "#545454";
        },
        
    buildButtons : function()
        {
        // Preload the rollover image into the browser's cache.
        (new Image( )).src = "http://littleshootimages.appspot.com/images/button100x22Over.gif";
        (new Image( )).src = "http://littleshootimages.appspot.com/images/button160x22Over.gif";
        dojo.query(".button").forEach(function(button) 
            {
            dojo.connect(button, "mouseover", null, function(event) 
                {
                Button.changeButtonOver(button, "url(http://littleshootimages.appspot.com/images/button100x22Over.gif)");
                }); 
            dojo.connect(button, "mouseout", null, function(event) 
                {
                Button.changeButtonOut(button, "url(http://littleshootimages.appspot.com/images/button100x22.gif)");
                });
            });
            
        dojo.query(".bigButton").forEach(function(button) 
            {
            dojo.connect(button, "mouseover", null, function(event) 
                {
                Button.changeButtonOver(button, "url(http://littleshootimages.appspot.com/images/button160x22Over.gif)");
                }); 
            dojo.connect(button, "mouseout", null, function(event) 
                {
                Button.changeButtonOut(button, "url(http://littleshootimages.appspot.com/images/button160x22.gif)");
                });
            });
        },
    
    enableButtonsByClass : function(buttonClass)
        {
        dojo.query("."+buttonClass).forEach(function(button) 
            {
            //
            // TODO: This is different in current dojo API.
            //dojo.html.setOpacity(button, 1.0);
            });
        },
    
    enableButtons : function()
        {    
        Button.enableButtonsByClass("button");
        Button.enableButtonsByClass("bigButton");
        },
    
    disableButton : function(button)
        {
        // Not working...
        //
        dojo.connect(button, "onclick", null, function(event) 
            {
            // TODO: This is just problematic for now.
            //CommonUtils.showPluginRequiredDialog();
            });
        },
    
    disableButtonsByClass : function(buttonClass)
        {
        //
        dojo.query("."+buttonClass).forEach(function(button) 
            {
            //
            Button.disableButton(button);
            });
        },
    
    disableButtons : function()
        {
        Button.disableButtonsByClass("button");
        Button.disableButtonsByClass("bigButton");
        }
    };

}
