dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_zh-tw"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.zh_tw"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.zh_tw"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.zh_tw"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_zh-tw");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.zh_tw");dojo.cldr.nls.number.zh_tw={"currencyFormat":"¤#,##0.00","group":",","list":";","decimalFormat":"#,##0.###","scientificFormat":"#E0","percentFormat":"#,##0%","decimal":".","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","infinity":"∞","percentSign":"%","minusSign":"-","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","nan":"NaN","nativeZeroDigit":"0","plusSign":"+","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","perMille":"‰","patternDigit":"#","currencySpacing-beforeCurrency-insertBetween":" ","exponential":"E"};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.zh_tw");dijit.nls.loading.zh_tw={"loadingState":"載入中...","errorState":"抱歉，發生錯誤"};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.zh_tw");dijit.nls.common.zh_tw={"buttonOk":"確定","buttonCancel":"取消","buttonSave":"儲存","itemClose":"關閉"};

}};});