dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_sk"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.sk"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.sk"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.sk"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_sk");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.sk");dojo.cldr.nls.number.sk={"currencyFormat":"#,##0.00 ¤","group":" ","decimal":",","scientificFormat":"#E0","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","infinity":"∞","list":";","percentSign":"%","minusSign":"-","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","nan":"NaN","nativeZeroDigit":"0","plusSign":"+","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","perMille":"‰","percentFormat":"#,##0%","decimalFormat":"#,##0.###","patternDigit":"#","currencySpacing-beforeCurrency-insertBetween":" ","exponential":"E"};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.sk");dijit.nls.loading.sk={"loadingState":"Zavádzanie...","errorState":"Nastala chyba"};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.sk");dijit.nls.common.sk={"buttonOk":"OK","buttonCancel":"Zrušiť","buttonSave":"Uložiť","itemClose":"Zatvoriť"};

}};});