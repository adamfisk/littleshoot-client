dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_sv"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.sv"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.sv"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.sv"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_sv");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.sv");dojo.cldr.nls.number.sv={"group":" ","percentSign":"%","exponential":"×10^","percentFormat":"#,##0 %","scientificFormat":"#E0","list":";","infinity":"∞","patternDigit":"#","minusSign":"−","decimal":",","nativeZeroDigit":"0","perMille":"‰","decimalFormat":"#,##0.###","currencyFormat":"#,##0.00 ¤","plusSign":"+","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","nan":"NaN","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","currencySpacing-beforeCurrency-insertBetween":" "};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.sv");dijit.nls.loading.sv={"loadingState":"Läser in...","errorState":"Det uppstod ett fel."};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.sv");dijit.nls.common.sv={"buttonOk":"OK","buttonCancel":"Avbryt","buttonSave":"Spara","itemClose":"Stäng"};

}};});