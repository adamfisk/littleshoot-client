dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_sl"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.sl"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.sl"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.sl"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_sl");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.sl");dojo.cldr.nls.number.sl={"group":".","percentSign":"%","exponential":"E","list":";","infinity":"∞","patternDigit":"#","minusSign":"-","decimal":",","nan":"NaN","nativeZeroDigit":"0","perMille":"‰","plusSign":"+","scientificFormat":"#E0","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencyFormat":"¤ #,##0.00","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","percentFormat":"#,##0%","decimalFormat":"#,##0.###","currencySpacing-beforeCurrency-insertBetween":" "};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.sl");dijit.nls.loading.sl={"loadingState":"Nalaganje...","errorState":"Oprostite, prišlo je do napake."};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.sl");dijit.nls.common.sl={"buttonOk":"V redu","buttonCancel":"Prekliči","buttonSave":"Shrani","itemClose":"Zapri"};

}};});