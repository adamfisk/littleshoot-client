dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_es-es"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.es_es"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.es_es"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.es_es"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_es-es");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.es_es");dojo.cldr.nls.number.es_es={"currencyFormat":"#,##0.00 ¤","decimalFormat":"#,##0.###","group":".","scientificFormat":"#E0","percentFormat":"#,##0%","decimal":",","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","infinity":"∞","list":";","percentSign":"%","minusSign":"-","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","nan":"NaN","nativeZeroDigit":"0","plusSign":"+","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","perMille":"‰","patternDigit":"#","currencySpacing-beforeCurrency-insertBetween":" ","exponential":"E"};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.es_es");dijit.nls.loading.es_es={"loadingState":"Cargando...","errorState":"Lo siento, se ha producido un error"};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.es_es");dijit.nls.common.es_es={"buttonOk":"Aceptar","buttonCancel":"Cancelar","buttonSave":"Guardar","itemClose":"Cerrar"};

}};});