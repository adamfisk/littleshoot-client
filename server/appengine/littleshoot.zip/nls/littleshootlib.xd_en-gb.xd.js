dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.nls.littleshootlib_en-gb"],
["provide", "dojo.cldr.nls.number"],
["provide", "dojo.cldr.nls.number.en_gb"],
["provide", "dijit.nls.loading"],
["provide", "dijit.nls.loading.en_gb"],
["provide", "dijit.nls.common"],
["provide", "dijit.nls.common.en_gb"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("littleshoot.nls.littleshootlib_en-gb");dojo.provide("dojo.cldr.nls.number");dojo.cldr.nls.number._built=true;dojo.provide("dojo.cldr.nls.number.en_gb");dojo.cldr.nls.number.en_gb={"currencyFormat":"¤#,##0.00","group":",","percentSign":"%","exponential":"E","percentFormat":"#,##0%","scientificFormat":"#E0","list":";","infinity":"∞","patternDigit":"#","minusSign":"-","decimal":".","nan":"NaN","nativeZeroDigit":"0","perMille":"‰","decimalFormat":"#,##0.###","plusSign":"+","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","currencySpacing-afterCurrency-insertBetween":" ","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","currencySpacing-beforeCurrency-insertBetween":" "};dojo.provide("dijit.nls.loading");dijit.nls.loading._built=true;dojo.provide("dijit.nls.loading.en_gb");dijit.nls.loading.en_gb={"loadingState":"Loading...","errorState":"Sorry, an error occurred"};dojo.provide("dijit.nls.common");dijit.nls.common._built=true;dojo.provide("dijit.nls.common.en_gb");dijit.nls.common.en_gb={"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close"};

}};});