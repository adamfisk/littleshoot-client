/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.DownloadStatus"]],
defineResource: function(dojo, dijit, dojox){if(!dojo._hasResource["littleshoot.DownloadStatus"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.DownloadStatus"] = true;
dojo.provide("littleshoot.DownloadStatus");


function refreshStatus()
    {
    
    this.downloadStatus.updateStatus();
    }

/**
 * Called from the server when it has obtained the download status.
 */
function onDownloadStatus(data)
    {
    var status = data.status;
    
    var statusSpan = dojo.byId("downloadStatusSpan");
    var statusText = document.createTextNode(status);
    statusSpan.replaceChild(statusText, statusSpan.firstChild);
    this.timeoutId = setTimeout(refreshStatus, 2000);
    }

dojo.declare("littleshoot.DownloadStatus", null, 
    {
    constructor : function(uri)
        {
        this.uri = uri;    
        this.url = Constants.CLIENT_URL + "downloadStatus";
        
        },
    
    updateStatus : function ()
        {
        var loadHandler = function(data, ioArgs)
            {
            onDownloadStatus(data);
            };
            
        var errorHandler = function(data, ioArgs)
            {
            CommonUtils.showError(dojo.toJson(data));
            };
            
        var params = 
            {
            uri: this.uri 
            };
    
        var deferred = dojo.io.script.get(
            { 
            url: this.url, 
            callbackParamName: "callback",
            load: loadHandler,
            error: errorHandler,
            content: params,
            timeout: 10000
            });
        }
    });
    
function updateDownloadStatus(uri)
    {
    
    this.downloadStatus = new littleshoot.DownloadStatus(uri);
    this.downloadStatus.updateStatus();
    } 
    

}

}};});
