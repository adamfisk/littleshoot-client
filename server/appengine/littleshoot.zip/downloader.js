/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["littleshoot.Downloader"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.Downloader"] = true;
dojo.provide("littleshoot.Downloader");

dojo.declare("littleshoot.Downloader", null, 
    {
    constructor : function(uri, fileName, size, urn, mimeType, source)
        {
        this.uri = uri;    
        this.fileName = fileName;
        this.size = size;
        this.mimeType = mimeType;
        this.urn = urn;
        this.source = source;
        
        },
    
    download : function ()
        {
        var loadHandler = function(data, ioArgs)
            {
            onDownloadRequested(data);
            };
            
        var errorHandler = function(data, ioArgs)
            {
            CommonUtils.showError(data);
            };
            
        var params = 
            {
            uri: this.uri, 
            name: this.fileName,
            urn: this.urn,
            size: this.size,
            mimeType: this.mimeType,
            noCache: (new Date()).getTime()
            };
        
        if (CommonUtils.inGroup())
            {
            params.groupName = CommonUtils.getGroupName();
            }
            
        
            
        var getParams = 
            { 
            url: Constants.CLIENT_URL + "download", 
            callbackParamName: "callback",
            load: loadHandler,
            error: errorHandler,
            content: params,
            timeout: 10000
            };
        
        var deferred = CommonUtils.get(getParams);
        },
        
    setFrameSrc : function (name, uri)
        {
        
        updateDownloadStatus(uri);
        var viewerPage;
        var mt = this.mimeType;
        
        var isSafari = /Safari/.test(navigator.userAgent);
        var isLinux = /Linux/.test(navigator.userAgent);
        
        
        
        var params = 
            {
            uri: this.uri, 
            name: this.fileName,
            urn: this.urn,
            size: this.size,
            mimeType: this.mimeType,
            source: this.source,
            noCache: (new Date()).getTime()
            };
        
        if (CommonUtils.inGroup())
            {
            params.groupName = CommonUtils.getGroupName();
            }
        
        var fileUrl = Constants.CLIENT_URL +"download?"+
            dojo.objectToQuery(params);
        
        
        //window.location.href = fileUrl;
        
        // Use the QuickTime plugin if it's supported.  Note that it doesn't
        // load correctly on at least some Safari versions.
        if ((mt == "video/mpeg" || mt == "video/quicktime") &&
            !isLinux)
            {
            
            viewerPage = "quickTimeViewer.html?url=" + 
                encodeURIComponent(fileUrl); 
            }
        else
            {
            
            
            viewerPage = fileUrl;
            }
        
        if (isSafari)
            {
            dojo.byId("downloadFrame").height = 500;
            }
            
        
        dojo.byId("downloadFrame").src = viewerPage;
        }
    });

}
