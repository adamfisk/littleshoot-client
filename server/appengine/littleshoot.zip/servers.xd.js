/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "littleshoot.Servers"]],
defineResource: function(dojo, dijit, dojox){if(!dojo._hasResource["littleshoot.Servers"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["littleshoot.Servers"] = true;
dojo.provide("littleshoot.Servers");

var Servers =
    {
    lastReturned: true,
    lastData: null,
    check : function()
        {
        
        if (Servers.lastReturned)
            {
            Servers.lastReturned = false;
            }
        else
            {
            
            return;
            }
        
        if (Servers.lastReturned)
            {
            console.error("Last returned now true!!");
            }
        
        var loadHandler = function(data, ioArgs)
            {
            
            Servers.lastData = data;
            clearTimeout(Servers.timeoutId);
            var serversInnerDiv = document.createElement("div");
            serversInnerDiv.id = "serversInnerDiv";
            for (var i = 0; i < data.servers.length; i++)
                {
                
                Servers.appendServer(data.servers[i], serversInnerDiv);
                }
            
            var serversDiv = dojo.byId("serversDiv");
            var existing = dojo.byId("serversInnerDiv");
            
            if (!existing)
                {
                serversDiv.appendChild(serversInnerDiv);
                }
            else
                {
                serversDiv.replaceChild(serversInnerDiv, existing);
                }
            
            Servers.scheduleCall();
            };
            
            
        var errorHandler = function(data, ioArgs)
            {
            console.error("Could not contact server: "+data);
            clearTimeout(Servers.timeoutId);
            CommonUtils.showError("Could not access servers: "+data);
            Servers.scheduleCall();
            };
        
        
        var url = "/lastbamboo-server-site/api/serverMonitor";
        
        
        
        var deferred = dojo.xhrGet(
            {
            url: url,
            load: loadHandler,
            error: errorHandler,
            handleAs: "json",
            timeout: 40000
            });
        deferred.addBoth(function()
            {
            Servers.lastReturned = true;
            });
        },
    
    appendServer : function(server, div)
        {
        
        var serverSpan = document.createElement("span");
        serverSpan.className = "serverSpan";
        var text = "<br>SERVER DATA:<br>";
        text += "<br>Server Address: ";
        text += server.socketAddress;
        text += "<br>Load average: "; 
        text += server.systemLoadAverage;
        text += "<br>Uptime: ";
        text += server.uptime;
        text += "<br>Peak Thread Count: ";
        text += server.peakThreadCount;
        text += "<br>Heap Memory Usage:<br>";
        text += server.heapMemoryUsage;
        text += "<br>Non Heap Memory Usage:<br>";
        text += server.nonHeapMemoryUsage;
        text += "<br>VM Version: ";
        text += server.vmVersion;
        text += "<br><br><br>SIP DATA:<br>";
        text += "<br>Users Registered: "+server.sipNumRegistered;
        text += "<br>Max Users Registered: "+server.sipMaxRegistered;
        text += "<br><br><br>TURN DATA:<br>";
        text += "<br>Current TURN Clients: ";
        text += server.numTurnClients;
        text += "<br>Maximum TURN Clients: ";
        text += server.maxNumTurnClients;
        text += "<br>Current Remote Hosts Connected to TURN Clients: ";
        text += server.numRemoteTurnClients;
        text += "<br>Maximum Remote Hosts Connected to TURN Clients: ";
        text += server.maxNumRemoteTurnClients;
        text += "<br>Maximum Remote Hosts Connected to a Single TURN Client: ";
        text += server.maxNumRemoteSingleTurnClient;
        
        
        serverSpan.innerHTML = text;
        div.appendChild(serverSpan);
        

        },
    
    start : function()
        {
        
        Servers.check();
        },
    
    scheduleCall : function()
        {
        var refreshTime = 2000;
        Servers.timeoutId = setTimeout(Servers.check, refreshTime);
        }
    };

}

}};});
