dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.tr.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.tr.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "tr", {"set":"Ayarla","text":"Açıklama:","insertImageTitle":"Resim Özellikleri","url":"URL:","createLinkTitle":"Bağlantı Özellikleri"});
}};});