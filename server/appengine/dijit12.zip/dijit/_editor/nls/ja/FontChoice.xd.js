dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.ja.FontChoice"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.ja.FontChoice");dojo._xdLoadFlattenedBundle("dijit._editor", "FontChoice", "ja", {"1":"超極小","2":"極小","formatBlock":"フォーマット","3":"小","4":"標準","5":"大","6":"特大","7":"超特大","fantasy":"fantasy","serif":"serif","p":"段落","pre":"事前フォーマット済み","sans-serif":"sans-serif","fontName":"フォント","h1":"見出し","h2":"副見出し","h3":"副見出しの副見出し","monospace":"monospace","fontSize":"サイズ","cursive":"cursive"});
}};});