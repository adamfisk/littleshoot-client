dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.ja.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.ja.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "ja", {"set":"設定","text":"説明:","insertImageTitle":"イメージ・プロパティー","url":"URL:","createLinkTitle":"リンク・プロパティー"});
}};});