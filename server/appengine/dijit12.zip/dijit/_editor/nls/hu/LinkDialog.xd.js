dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.hu.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.hu.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "hu", {"set":"Beállítás","text":"Leírás:","insertImageTitle":"Kép tulajdonságai","url":"URL:","createLinkTitle":"Hivatkozás tulajdonságai"});
}};});