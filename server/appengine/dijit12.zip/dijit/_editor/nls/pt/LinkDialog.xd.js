dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.pt.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.pt.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "pt", {"set":"Definir","text":"Descrição: ","insertImageTitle":"Propriedades de Imagem","url":"URL:","createLinkTitle":"Propriedades de Link"});
}};});