dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.zh-tw.FontChoice"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.zh-tw.FontChoice");dojo._xdLoadFlattenedBundle("dijit._editor", "FontChoice", "zh-tw", {"1":"最小","2":"較小","formatBlock":"格式","3":"小","4":"中","5":"大","6":"較大","7":"最大","fantasy":"Fantasy","serif":"新細明體","p":"段落","pre":"預先格式化","sans-serif":"新細明體","fontName":"字型","h1":"標題","h2":"子標題","h3":"次子標題","monospace":"等寬","fontSize":"大小","cursive":"Cursive"});
}};});