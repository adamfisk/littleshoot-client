dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.ko.FontChoice"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.ko.FontChoice");dojo._xdLoadFlattenedBundle("dijit._editor", "FontChoice", "ko", {"1":"가장 작게","2":"조금 작게","formatBlock":"서식","3":"작게","4":"중간","5":"크게","6":"조금 크게","7":"가장 크게","fantasy":"fantasy","serif":"serif","p":"단락","pre":"서식이 지정됨","sans-serif":"sans-serif","fontName":"글꼴","h1":"제목","h2":"부제목","h3":"하위 부제목","monospace":"monospace","fontSize":"크기","cursive":"cursive"});
}};});