dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.he.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.he.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "he", {"previousMessage":"האפשרויות הקודמות","nextMessage":"אפשרויות נוספות"});
}};});