dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.cs.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.cs.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "cs", {"previousMessage":"Předchozí volby","nextMessage":"Další volby"});
}};});