dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.fi.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.fi.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "fi", {"iframeEditTitle":"muokkausalue","iframeFocusTitle":"muokkausalueen kehys"});
}};});