dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ar.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ar.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ar", {"rangeMessage":"هذه القيمة ليس بالمدى الصحيح.","invalidMessage":"القيمة التي تم ادخالها غير صحيحة.","missingMessage":"يجب ادخال هذه القيمة."});
}};});