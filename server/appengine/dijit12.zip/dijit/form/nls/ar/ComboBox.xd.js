dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ar.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ar.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ar", {"previousMessage":"الاختيارات السابقة","nextMessage":"مزيد من الاختيارات"});
}};});