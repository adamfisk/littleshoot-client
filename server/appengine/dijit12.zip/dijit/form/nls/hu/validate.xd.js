dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.hu.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.hu.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "hu", {"rangeMessage":"Az érték kívül van a megengedett tartományon.","invalidMessage":"A megadott érték érvénytelen.","missingMessage":"Meg kell adni egy értéket."});
}};});