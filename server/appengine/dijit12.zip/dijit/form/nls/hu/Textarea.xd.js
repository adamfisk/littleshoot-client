dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.hu.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.hu.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "hu", {"iframeEditTitle":"szerkesztési terület","iframeFocusTitle":"szerkesztési terület keret"});
}};});