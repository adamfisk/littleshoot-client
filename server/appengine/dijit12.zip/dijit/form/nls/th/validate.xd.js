dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.th.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.th.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "th", {"rangeMessage":"ค่านี้เกินช่วง","invalidMessage":"ค่าที่ป้อนไม่ถูกต้อง","missingMessage":"จำเป็นต้องมีค่านี้"});
}};});