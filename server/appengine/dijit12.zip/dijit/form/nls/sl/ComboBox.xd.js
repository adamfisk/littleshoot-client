dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.sl.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.sl.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "sl", {"previousMessage":"Prejšnje možnosti","nextMessage":"Dodatne možnosti"});
}};});