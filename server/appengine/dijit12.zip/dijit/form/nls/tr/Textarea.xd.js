dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.tr.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.tr.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "tr", {"iframeEditTitle":"düzenleme alanı","iframeFocusTitle":"düzenleme alanı çerçevesi"});
}};});