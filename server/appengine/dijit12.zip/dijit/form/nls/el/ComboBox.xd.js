dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.el.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.el.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "el", {"previousMessage":"Προηγούμενες επιλογές","nextMessage":"Περισσότερες επιλογές"});
}};});