dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.el.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.el.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "el", {"iframeEditTitle":"περιοχή επεξεργασίας","iframeFocusTitle":"πλαίσιο περιοχής επεξεργασίας"});
}};});