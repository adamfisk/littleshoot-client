dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.he.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.he.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "he", ({"EUR_displayName":"אירו","CHF_displayName":"פרנק שוויצרי","HKD_displayName":"דולר הונג קונגי","CAD_displayName":"דולר קנדי","GBP_displayName":"לירה שטרלינג","JPY_displayName":"ין יפני","AUD_displayName":"דולר אוסטרלי","USD_displayName":"דולר אמריקאי","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});