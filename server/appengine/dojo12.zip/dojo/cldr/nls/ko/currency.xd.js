dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.ko.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.ko.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "ko", ({"HKD_displayName":"홍콩 달러","CHF_displayName":"스위스 프랑","JPY_symbol":"￥","HKD_symbol":"HK$","CAD_displayName":"캐나다 달러","CNY_displayName":"중국 위안 인민폐","AUD_displayName":"호주 달러","JPY_displayName":"일본 엔","CAD_symbol":"Can$","USD_displayName":"미국 달러","CNY_symbol":"¥","GBP_displayName":"영국령 파운드 스털링","AUD_symbol":"A$","EUR_displayName":"유로화","USD_symbol":"US$","GBP_symbol":"UK£","EUR_symbol":"€"})
);
}};});