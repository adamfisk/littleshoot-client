dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.da.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.da.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "da", ({"HKD_displayName":"Hongkong dollar","CHF_displayName":"Schweizisk franc","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Canadisk dollar","CNY_displayName":"Kinesisk yuan renminbi","USD_symbol":"$","AUD_displayName":"Australsk dollar","JPY_displayName":"Japansk yen","CAD_symbol":"Can$","USD_displayName":"Amerikansk dollar","CNY_symbol":"Y","GBP_displayName":"Britisk pund","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"Euro","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});