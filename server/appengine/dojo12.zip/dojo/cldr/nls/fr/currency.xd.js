dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.fr.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.fr.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "fr", ({"HKD_displayName":"dollar de Hong Kong","CHF_displayName":"franc suisse","CHF_symbol":"sFr.","JPY_symbol":"¥JP","HKD_symbol":"$HK","CAD_displayName":"dollar canadien","CNY_displayName":"yuan renminbi chinois","USD_symbol":"$US","AUD_displayName":"dollar australien","JPY_displayName":"yen japonais","CAD_symbol":"$Ca","USD_displayName":"dollar des États-Unis","CNY_symbol":"Ұ","GBP_displayName":"livre sterling","GBP_symbol":"£UK","AUD_symbol":"$A","EUR_displayName":"euro","EUR_symbol":"€"})
);
}};});