dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "", ({"USD_symbol":"US$","EUR_displayName":"EUR","GBP_displayName":"GBP","JPY_displayName":"JPY","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€","USD_displayName":"USD"})
);
}};});