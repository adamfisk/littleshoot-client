dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.cs.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.cs.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "cs", ({"HKD_displayName":"Dolar hongkongský","CHF_displayName":"Frank švýcarský","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Dolar kanadský","CNY_displayName":"Juan renminbi","AUD_displayName":"Dolar australský","JPY_displayName":"Jen","CAD_symbol":"Can$","USD_displayName":"Dolar americký","CNY_symbol":"Y","GBP_displayName":"Libra šterlinků","AUD_symbol":"$A","EUR_displayName":"Euro","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});