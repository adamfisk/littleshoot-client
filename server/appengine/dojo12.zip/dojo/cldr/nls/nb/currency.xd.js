dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.nb.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.nb.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "nb", ({"HKD_displayName":"Hongkong-dollar","CHF_displayName":"sveitsiske franc","JPY_symbol":"JPY","CAD_displayName":"kanadiske dollar","CNY_displayName":"kinesiske yuan renminbi","USD_symbol":"USD","AUD_displayName":"australske dollar","JPY_displayName":"japanske yen","USD_displayName":"amerikanske dollar","EUR_symbol":"EUR","GBP_displayName":"britiske pund sterling","GBP_symbol":"GBP","EUR_displayName":"euro"})
);
}};});