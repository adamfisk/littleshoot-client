dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.hu.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.hu.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "hu", ({"HKD_displayName":"Hongkongi dollár","CHF_displayName":"Svájci frank","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Kanadai dollár","CNY_displayName":"Kínai jüan renminbi","USD_symbol":"USD","AUD_displayName":"Ausztrál dollár","JPY_displayName":"Japán jen","CAD_symbol":"Can$","USD_displayName":"USA dollár","CNY_symbol":"Y","GBP_displayName":"Brit font sterling","AUD_symbol":"$A","EUR_displayName":"Euro","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});