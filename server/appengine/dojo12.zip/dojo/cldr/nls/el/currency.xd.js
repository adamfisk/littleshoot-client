dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.el.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.el.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "el", ({"HKD_displayName":"Δολάριο Χονγκ Κονγκ","CHF_displayName":"Φράγκο Ελβετίας","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Δολάριο Καναδά","CNY_displayName":"Γιουάν Ρενμίμπι Κίνας","AUD_displayName":"Δολάριο Αυστραλίας","JPY_displayName":"Γιεν Ιαπωνίας","CAD_symbol":"Can$","USD_displayName":"Δολάριο ΗΠΑ","CNY_symbol":"Y","GBP_displayName":"Λίρα Στερλίνα Βρετανίας","GBP_symbol":"GBP","AUD_symbol":"$A","EUR_displayName":"Ευρώ","USD_symbol":"US$","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});