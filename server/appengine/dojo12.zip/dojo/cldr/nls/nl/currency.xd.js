dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.nl.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.nl.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "nl", ({"HKD_displayName":"Hongkongse dollar","CHF_displayName":"Zwitserse franc","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Canadese dollar","CNY_displayName":"Chinese yuan renminbi","USD_symbol":"USD","AUD_displayName":"Australische dollar","JPY_displayName":"Japanse yen","CAD_symbol":"Can$","USD_displayName":"Amerikaanse dollar","CNY_symbol":"Y","GBP_displayName":"Brits pond sterling","GBP_symbol":"GBP","AUD_symbol":"$A","EUR_displayName":"euro","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});