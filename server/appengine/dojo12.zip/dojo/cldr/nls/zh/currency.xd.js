dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.zh.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.zh.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "zh", ({"HKD_displayName":"港元","CHF_displayName":"瑞士法郎","HKD_symbol":"HK$","CAD_displayName":"加拿大元","CNY_displayName":"人民币","AUD_displayName":"澳大利亚元","JPY_displayName":"日元","USD_displayName":"美元","CNY_symbol":"￥","GBP_displayName":"英镑","EUR_displayName":"欧元","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});