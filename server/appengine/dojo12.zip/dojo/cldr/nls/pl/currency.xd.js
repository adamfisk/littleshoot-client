dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.pl.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.pl.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "pl", ({"HKD_displayName":"dolar hongkoński","CHF_displayName":"frank szwajcarski","CHF_symbol":"SwF","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"dolar kanadyjski","CNY_displayName":"juan renminbi","USD_symbol":"$","AUD_displayName":"dolar australijski","JPY_displayName":"jen japoński","CAD_symbol":"Can$","USD_displayName":"dolar amerykański ","CNY_symbol":"Y","GBP_displayName":"funt szterling","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"euro","EUR_symbol":"€"})
);
}};});