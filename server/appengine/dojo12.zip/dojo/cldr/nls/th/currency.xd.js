dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.th.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.th.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "th", ({"HKD_displayName":"เหรียญฮ่องกง","CHF_displayName":"ฟรังก์สวิส","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"ดอลลาร์แคนาดา","CNY_displayName":"หยวนเหรินเหมินบี้","USD_symbol":"US$","AUD_displayName":"ดอลลาร์ออสเตรเลีย","JPY_displayName":"เยน","CAD_symbol":"Can$","USD_displayName":"ดอลลาร์สหรัฐ","EUR_symbol":"€","CNY_symbol":"￥","GBP_displayName":"ปอนด์สเตอร์ลิงอังกฤษ","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"ยูโร"})
);
}};});