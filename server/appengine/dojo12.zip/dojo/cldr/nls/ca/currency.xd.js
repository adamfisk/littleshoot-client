dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.ca.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.ca.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "ca", ({"EUR_displayName":"Euro","CHF_displayName":"Franc suís","GBP_displayName":"Lliura esterlina britànica","JPY_displayName":"Ien japonès","CNY_displayName":"Iuan renmimbi xinès","USD_displayName":"Dòlar EUA","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});