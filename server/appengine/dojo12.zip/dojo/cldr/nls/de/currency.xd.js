dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.de.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.de.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "de", ({"HKD_displayName":"Hongkong-Dollar","CHF_displayName":"Schweizer Franken","CHF_symbol":"SFr.","JPY_symbol":"¥","CAD_displayName":"Kanadischer Dollar","CNY_displayName":"Renminbi Yuan","USD_symbol":"$","AUD_displayName":"Australischer Dollar","JPY_displayName":"Yen","CAD_symbol":"Can$","USD_displayName":"US-Dollar","CNY_symbol":"Y","GBP_displayName":"Pfund Sterling","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"Euro","EUR_symbol":"€"})
);
}};});