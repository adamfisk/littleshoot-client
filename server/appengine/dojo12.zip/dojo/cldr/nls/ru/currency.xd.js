dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.ru.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.ru.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "ru", ({"HKD_displayName":"Гонконгский доллар","CHF_displayName":"Швейцарский франк","CHF_symbol":"SwF","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"Канадский доллар","CNY_displayName":"Юань Ренминби","USD_symbol":"$","AUD_displayName":"Австралийский доллар","JPY_displayName":"Японская иена","CAD_symbol":"Can$","USD_displayName":"Доллар США","CNY_symbol":"Y","GBP_displayName":"Английский фунт стерлингов","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"Евро","EUR_symbol":"€"})
);
}};});