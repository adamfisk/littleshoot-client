dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.ja.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.ja.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "ja", ({"HKD_displayName":"香港ドル","CHF_displayName":"スイス フラン","JPY_symbol":"￥","CAD_displayName":"カナダ ドル","CNY_displayName":"中国人民元","AUD_displayName":"オーストラリア ドル","JPY_displayName":"日本円","USD_displayName":"米ドル","CNY_symbol":"元","GBP_displayName":"英国ポンド","EUR_displayName":"ユーロ","USD_symbol":"US$","GBP_symbol":"UK£","EUR_symbol":"€"})
);
}};});