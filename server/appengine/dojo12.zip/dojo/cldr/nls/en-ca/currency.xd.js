dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.en-ca.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.en-ca.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "en-ca", ({"CAD_symbol":"$","USD_symbol":"US$","HKD_displayName":"Hong Kong Dollar","CHF_displayName":"Swiss Franc","CHF_symbol":"Fr.","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"Canadian Dollar","CNY_displayName":"Chinese Yuan Renminbi","AUD_displayName":"Australian Dollar","JPY_displayName":"Japanese Yen","USD_displayName":"US Dollar","CNY_symbol":"RMB","GBP_displayName":"British Pound Sterling","GBP_symbol":"£","AUD_symbol":"A$","EUR_displayName":"Euro","EUR_symbol":"€"})
);
}};});