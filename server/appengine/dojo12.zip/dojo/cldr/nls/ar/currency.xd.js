dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.ar.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.ar.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "ar", ({"HKD_displayName":"دولار هونج كونج","CHF_displayName":"فرنك سويسرى","CAD_displayName":"دولار كندى","CNY_displayName":"يوان صيني","AUD_displayName":"دولار أسترالى","JPY_displayName":"ين ياباني","USD_displayName":"دولار أمريكي","GBP_displayName":"جنيه سترليني","EUR_displayName":"يورو","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});