dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.fi.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.fi.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "fi", ({"HKD_displayName":"Hongkongin dollari","CHF_displayName":"Sveitsin frangi","JPY_symbol":"¥","CAD_displayName":"Kanadan dollari","CNY_displayName":"Kiinan yuan","USD_symbol":"$","AUD_displayName":"Australian dollari","JPY_displayName":"Japanin jeni","USD_displayName":"Yhdysvaltain dollari","GBP_displayName":"Englannin punta","GBP_symbol":"£","EUR_displayName":"euro","EUR_symbol":"€"})
);
}};});