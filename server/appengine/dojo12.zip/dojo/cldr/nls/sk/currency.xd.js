dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.sk.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.sk.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "sk", ({"HKD_displayName":"Hong Kongský dolár","CHF_displayName":"Švajčiarský frank","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"Kanadský dolár","CNY_displayName":"Čínsky Yuan Renminbi","AUD_displayName":"Austrálsky dolár","JPY_displayName":"Japonský yen","CAD_symbol":"Can$","USD_displayName":"US dolár","CNY_symbol":"Y","GBP_displayName":"Britská libra","AUD_symbol":"$A","EUR_displayName":"Euro","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});