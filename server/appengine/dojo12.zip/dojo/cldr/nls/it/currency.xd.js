dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.it.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.it.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "it", ({"HKD_displayName":"Dollaro di Hong Kong","CHF_displayName":"Franco Svizzero","CHF_symbol":"SFr.","CAD_displayName":"Dollaro Canadese","CNY_displayName":"Renmimbi Cinese","AUD_displayName":"Dollaro Australiano","JPY_displayName":"Yen Giapponese","USD_displayName":"Dollaro Statunitense","GBP_displayName":"Sterlina Inglese","EUR_displayName":"Euro","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});