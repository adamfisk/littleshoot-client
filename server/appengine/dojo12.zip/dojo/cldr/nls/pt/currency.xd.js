dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.pt.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.pt.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "pt", ({"HKD_displayName":"Dólar de Hong Kong","CHF_displayName":"Franco suíço","CHF_symbol":"SwF","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"Dólar canadense","CNY_displayName":"Yuan Renminbi chinês","AUD_displayName":"Dólar australiano","JPY_displayName":"Iene japonês","CAD_symbol":"Can$","USD_displayName":"Dólar norte-americano","CNY_symbol":"Y","GBP_displayName":"Libra esterlina britânica","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"Euro","USD_symbol":"US$","EUR_symbol":"€"})
);
}};});