dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.tr.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.tr.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "tr", ({"HKD_displayName":"Hong Kong Doları","CHF_displayName":"İsviçre Frangı","CHF_symbol":"SwF","JPY_symbol":"¥","HKD_symbol":"HK$","CAD_displayName":"Kanada Doları","CNY_displayName":"Çin Yuanı Renminbi","USD_symbol":"$","AUD_displayName":"Avustralya Doları","JPY_displayName":"Japon Yeni","CAD_symbol":"Can$","USD_displayName":"ABD Doları","CNY_symbol":"Y","GBP_displayName":"İngiliz Sterlini","GBP_symbol":"£","AUD_symbol":"$A","EUR_displayName":"Euro","EUR_symbol":"€"})
);
}};});