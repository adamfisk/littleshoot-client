dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.sl.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.sl.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "sl", ({"EUR_displayName":"Evro","GBP_displayName":"Britanski Funt Sterling","JPY_displayName":"Japonski Jen","CNY_displayName":"Kitajski Yuan Renminbi","USD_displayName":"Ameriški Dolar","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});