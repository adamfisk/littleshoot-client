dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dojo.cldr.nls.sv.currency"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dojo.cldr.nls.sv.currency");dojo._xdLoadFlattenedBundle("dojo.cldr", "currency", "sv", ({"HKD_displayName":"Hongkong-dollar","CHF_displayName":"schweizisk franc","CHF_symbol":"SwF","HKD_symbol":"HK$","CAD_displayName":"kanadensisk dollar","CNY_displayName":"kinesisk yuan renminbi","AUD_displayName":"australisk dollar","JPY_displayName":"japansk yen","CAD_symbol":"Can$","USD_displayName":"US-dollar","CNY_symbol":"Y","GBP_displayName":"brittiskt pund sterling","AUD_symbol":"$A","EUR_displayName":"euro","USD_symbol":"US$","GBP_symbol":"UK£","JPY_symbol":"JP¥","EUR_symbol":"€"})
);
}};});